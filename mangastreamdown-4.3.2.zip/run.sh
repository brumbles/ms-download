#!/bin/sh

java -jar MangaStreamDL.jar